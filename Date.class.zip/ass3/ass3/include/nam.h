#ifndef NAM_H
#define NAM_H


class nam
{
    public:
        nam();
        virtual ~nam();
    protected:
    private:
};

#endif // NAM_H
