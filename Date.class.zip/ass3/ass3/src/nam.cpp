#include "nam.h"

nam::nam()
{
    //ctor
}

nam::~nam()
{
    //dtor
}
